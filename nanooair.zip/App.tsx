
import React, { useState, useEffect, useCallback } from 'react';
import { GeneratorForm } from './components/GeneratorForm';
import { ImageGallery } from './components/ImageGallery';
import { ImageModal } from './components/ImageModal';
import { generateImage } from './services/geminiService';
import { GeneratedImage, AspectRatio } from './types';

const App: React.FC = () => {
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [hasApiKey, setHasApiKey] = useState(false);
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);

  const checkApiKey = useCallback(async () => {
    try {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      setHasApiKey(hasKey);
    } catch (e) {
      console.error("Failed to check API key", e);
    }
  }, []);

  useEffect(() => {
    checkApiKey();
    const interval = setInterval(checkApiKey, 5000);
    window.addEventListener('focus', checkApiKey);
    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', checkApiKey);
    };
  }, [checkApiKey]);

  const handleGenerate = async (prompt: string, aspectRatio: AspectRatio, referenceImages?: string[]) => {
    if (!hasApiKey) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }

    const generationId = Math.random().toString(36).substr(2, 9);
    
    // Create a pending placeholder immediately
    const pendingImage: GeneratedImage = {
      id: generationId,
      prompt,
      aspectRatio,
      timestamp: Date.now(),
      status: 'pending'
    };

    setImages((prev) => [pendingImage, ...prev]);

    // Start background generation
    try {
      const imageUrl = await generateImage({ prompt, aspectRatio, referenceImages });
      
      setImages((prev) => 
        prev.map(img => 
          img.id === generationId 
            ? { ...img, status: 'success', url: imageUrl || undefined } 
            : img
        )
      );
    } catch (err: any) {
      console.error(err);
      const isApiKeyError = err.message?.includes("Requested entity was not found");
      
      if (isApiKeyError) {
        setHasApiKey(false);
        window.aistudio.openSelectKey();
      }

      setImages((prev) => 
        prev.map(img => 
          img.id === generationId 
            ? { ...img, status: 'error', errorMessage: isApiKeyError ? "API Key Error" : (err.message || "Failed") } 
            : img
        )
      );
    }
  };

  return (
    <main className="min-h-screen bg-black flex items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-6xl mx-auto bg-black/70 backdrop-blur-sm border border-gray-800 p-4 md:p-10 rounded-xl shadow-2xl">
        
        {/* Top Header */}
        <div className="flex flex-col md:flex-row items-center justify-between mb-8 gap-4 border-b border-gray-800 pb-8">
          <div className="flex flex-col">
            <h1 className="text-xl md:text-2xl font-bold tracking-tighter text-white">
              NANOO AIR<span className="text-gray-500 font-normal"> / BATCH GENERATOR</span>
            </h1>
            <p className="text-[10px] text-gray-500 font-mono tracking-widest uppercase mt-1">
              Fire multiple prompts without waiting
            </p>
          </div>
          <div className="flex items-center gap-3">
            <a 
              href="https://ai.google.dev/gemini-api/docs/billing" 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-4 py-2 text-xs font-semibold bg-transparent border border-gray-700 text-white hover:bg-gray-800 rounded flex items-center gap-2 transition-all"
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
              </svg>
              Rent API Key
            </a>
            <button 
              onClick={() => window.aistudio.openSelectKey()}
              className={`px-4 py-2 text-xs font-semibold border rounded flex items-center gap-2 transition-all ${hasApiKey ? 'bg-white text-black border-white' : 'bg-transparent border-gray-700 text-white hover:bg-gray-800'}`}
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path>
              </svg>
              {hasApiKey ? 'API Active' : 'Add API Key'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Left Column: Form */}
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-gray-800 pb-4">
              <h3 className="text-sm font-bold flex items-center gap-2 text-white">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"></polygon>
                </svg>
                INPUT
              </h3>
              <div className="px-3 py-1 bg-gray-900 border border-gray-700 text-[10px] font-bold text-gray-400">
                NANOO FLASH
              </div>
            </div>
            
            <GeneratorForm 
              onGenerate={handleGenerate} 
              hasApiKey={hasApiKey}
            />
          </div>

          {/* Right Column: Gallery */}
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-gray-800 pb-4">
              <h3 className="text-sm font-bold flex items-center gap-2 text-white">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                  <circle cx="8.5" cy="8.5" r="1.5"></circle>
                  <polyline points="21,15 16,10 5,21"></polyline>
                </svg>
                LIVE FEED
              </h3>
            </div>
            
            <div className="max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
              <ImageGallery images={images} onExpandImage={setSelectedImage} />
            </div>
          </div>
        </div>

        {/* Minimalist Footer */}
        <div className="mt-12 pt-8 border-t border-gray-800 flex justify-center">
          <p className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">
            Powered by Gemini Pro • NanooAir Studio
          </p>
        </div>
      </div>

      {selectedImage && (
        <ImageModal 
          image={selectedImage} 
          onClose={() => setSelectedImage(null)} 
        />
      )}
    </main>
  );
};

export default App;
