
import React from 'react';
import { GeneratedImage } from '../types';

interface ImageCardProps {
  image: GeneratedImage;
  onExpand?: () => void;
}

export const ImageCard: React.FC<ImageCardProps> = ({ image, onExpand }) => {
  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!image.url) return;
    const link = document.createElement('a');
    link.href = image.url;
    link.download = `nanooair-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getAspectClass = (ratio: string) => {
    switch (ratio) {
      case '1:1': return 'aspect-square';
      case '3:4': return 'aspect-[3/4]';
      case '4:3': return 'aspect-[4/3]';
      case '9:16': return 'aspect-[9/16]';
      case '16:9': return 'aspect-[16/9]';
      default: return 'aspect-square';
    }
  };

  if (image.status === 'pending') {
    return (
      <div className="border border-gray-800 bg-gray-950/20 animate-pulse">
        <div className={`relative flex items-center justify-center ${getAspectClass(image.aspectRatio)} bg-gray-900/40`}>
           <div className="flex flex-col items-center gap-4">
             <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
             <div className="text-center px-4">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Processing</p>
                <p className="text-[8px] text-gray-600 font-mono line-clamp-1 italic max-w-[120px]">"{image.prompt}"</p>
             </div>
           </div>
        </div>
        <div className="p-3 border-t border-gray-800 flex justify-between items-center bg-gray-950/50">
          <span className="text-[8px] font-bold text-gray-700 uppercase tracking-widest animate-pulse">
            QUEUED / {image.aspectRatio}
          </span>
        </div>
      </div>
    );
  }

  if (image.status === 'error') {
    return (
      <div className="border border-red-900/50 bg-red-950/10">
        <div className={`relative flex items-center justify-center ${getAspectClass(image.aspectRatio)} bg-red-950/20`}>
           <div className="flex flex-col items-center gap-2 text-red-500">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
             </svg>
             <p className="text-[8px] font-bold uppercase tracking-widest">{image.errorMessage || 'FAILED'}</p>
           </div>
        </div>
        <div className="p-3 border-t border-red-900/30 flex justify-between items-center bg-red-950/30">
          <span className="text-[8px] font-bold text-red-800 uppercase tracking-widest">
            ERROR / {image.aspectRatio}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="border border-gray-800 bg-black group transition-all hover:border-white cursor-pointer" onClick={onExpand}>
      <div className={`relative overflow-hidden ${getAspectClass(image.aspectRatio)} bg-gray-900/50`}>
        <img 
          src={image.url} 
          alt={image.prompt}
          className="w-full h-full object-contain"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4 gap-2">
          <p className="text-[10px] text-gray-300 font-mono line-clamp-2 italic mb-1">
            "{image.prompt}"
          </p>
          
          <div className="flex justify-center mb-1">
            <button 
              onClick={(e) => { e.stopPropagation(); onExpand?.(); }}
              className="bg-white/10 border border-white/20 hover:bg-white/20 text-white p-2 rounded-full transition-all flex items-center justify-center"
              title="Expand View"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
              </svg>
            </button>
          </div>

          <div className="flex gap-2">
            <button 
              onClick={handleDownload}
              className="flex-1 bg-white text-black py-2 text-[10px] font-bold uppercase tracking-widest hover:bg-gray-200 transition-all"
            >
              Download
            </button>
            <button 
              onClick={(e) => e.stopPropagation()}
              className="px-3 py-2 border border-gray-600 text-white hover:border-white transition-all text-xs"
            >
              ❤️
            </button>
          </div>
        </div>
      </div>
      <div className="p-3 border-t border-gray-800 flex justify-between items-center bg-gray-950/50">
        <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">
          {image.aspectRatio} / PRO
        </span>
        <span className="text-[8px] font-bold text-gray-700">
          ID: {image.id.toUpperCase()}
        </span>
      </div>
    </div>
  );
};
